import json
from discord_webhook.webhook import DiscordWebhook

def lambda_handler(event, context):
    try:
        # Extract relevant data from SNS message
        message = json.loads(event['Records'][0]['Sns']['Message'])
        data = {
            "AlarmName": message['AlarmName'],
            "AlarmConfigurationUpdatedTimestamp": message['AlarmConfigurationUpdatedTimestamp'],
            "MetricName": message['Trigger']['MetricName'],
            "Namespace": message['Trigger']['Namespace'],
            "Statistic": message['Trigger']['Statistic'],
            "Threshold": message['Trigger']['Threshold'],
        }

        # Use a template string for message formatting
        formatted_message = f"""**CloudWatch Notification for RDS:**\n
                        * Alarm Name: {data.get('AlarmName')}
                        * Updated At: {data.get('AlarmConfigurationUpdatedTimestamp')}
                        * Metric Name: {data.get('MetricName')}
                        * Namespace: {data.get('Namespace')}
                        * Statistic: {data.get('Statistic')}
                        * Threshold: {data.get('Threshold')}
                        """

        # Send message to Discord using webhook
        webhook = DiscordWebhook(url="https://discord.com/api/webhooks/1221091229421273139/xDy2bjB9Ws5XUliU33pfTCjCFSaBAbZAcsVvKibF8bw9VxO9JRa_FtPGjPJDGY7AukUW", content=formatted_message)
        webhook.execute()

        return {
            'statusCode': 200,
            'body': json.dumps('Message sent to Discord with formatted data'),
            'alarm_name': data.get('AlarmName')
        }
    except Exception as e:
        webhook = DiscordWebhook(url="https://discord.com/api/webhooks/1221091229421273139/xDy2bjB9Ws5XUliU33pfTCjCFSaBAbZAcsVvKibF8bw9VxO9JRa_FtPGjPJDGY7AukUW", content="Error Occured while sending message to Discord")
        webhook.execute()

        return {
            'statusCode': 400,
            'body': json.dumps(f'Error sending message to Discord: {e}'),
            'alarm_name': None

        }